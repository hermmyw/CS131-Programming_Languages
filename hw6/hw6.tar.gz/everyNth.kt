fun<T> everyNth(lst: List<T>, N: Int) : List<T>{
    if (N <= 0 || N > lst.size) {
        println("Error: please provide a valid N")
        return emptyList()
    }
    var ret = listOf<T>()
    for (i in 0..(lst.size-1)) {
        if ((i+1) % N == 0) {  // every Nth element
            ret += lst[i]
        }
    }
    return ret
}

fun main(args: Array<String>) {
    var lst1 = listOf('a', '2', '3', '4')
    var lst2 = listOf(1,2,3,4,6,7,8)
    var lst3 = listOf(null)
    var lst4 = listOf("Hello", "World", "!")

    println("Test1: valid N value...")
    var rl1 = everyNth(lst1, -10)
    check(rl1.isEmpty())
    rl1 = everyNth(lst1, 10)
    check(rl1.isEmpty())
    println("Passed")

    println("Test2: immutable returned list")
    val rl2 = everyNth(lst1, 2)
    check(rl2.equals(listOf('2','4')))
    lst1 = listOf('2', '3', '4', '5')  // change the original array
    check(rl2.equals(listOf('2','4')))
    check(lst1.equals(listOf('2', '3', '4', '5')))
    println("Passed")

    println("Test3: int list")
    val rl3 = everyNth(lst2, 3)
    check(rl3.equals(listOf(3,7)))
    println("Passed")

    println("Test4: empty list")
    val rl4 = everyNth(lst3, 1)
    check(rl4.equals(listOf(null)))
    println("Passed")

    println("Test5: string list")
    val rl5 = everyNth(lst4, 1)
    check(rl5.equals(listOf("Hello", "World", "!")))
    println("Passed")
}